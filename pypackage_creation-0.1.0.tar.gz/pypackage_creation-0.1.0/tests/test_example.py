def test_sample():
    """Sample test function."""
    assert True
