# PyPackage Creation

A sample Python package demonstrating proper package structure.

## Features

- 🧑‍💼 Realistic customer profiles with names, emails, and addresses
- 📦 Synthetic order data with timestamps and status tracking
- 🏷️ Product catalog generation with categories and pricing
- ✅ Built-in data validation and error handling
- 📊 Pandas DataFrame output format
- 🔧 Highly configurable data volumes and parameters

## Installation

```bash
pip install pypackage_creation
```

## Quick Start

```python
from data_generation import (
    generate_customer_data,
    generate_order_data,
    generate_product_data
)

# Generate synthetic data
customers = generate_customer_data(n_records=100)
products = generate_product_data(n_records=50)
orders = generate_order_data(n_records=1000)

# Example: Export to CSV
customers.to_csv('customers.csv', index=False)
products.to_csv('products.csv', index=False)
orders.to_csv('orders.csv', index=False)
```

## Usage

```python
from pypackage_creation import example

# Add usage examples here
```

## Data Schemas

### Customer Data
- customer_id (UUID)
- name (str)
- email (str)
- address (str)
- phone (str)

### Order Data
- order_id (UUID)
- customer_id (UUID)
- order_date (datetime)
- total_amount (float)
- status (str: pending/completed/shipped)

### Product Data
- product_id (UUID)
- name (str)
- category (str)
- price (float)
- description (str)

## Development Setup

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/snowflake-data-generator.git
   cd snowflake-data-generator
   ```

2. Create and activate virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # Linux/Mac
   # or
   .\venv\Scripts\activate  # Windows
   ```

3. Install development dependencies:
   ```bash
   pip install -e ".[dev]"
   ```

## Testing

Run the full test suite:
```bash
pytest
```

Run with coverage:
```bash
pytest --cov=data_generation tests/
```

## Dependencies

- Python >=3.8
- pandas >=1.3.0
- numpy >=1.20.0
- faker >=8.0.0

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)

3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

MIT

## Support

- Report issues on GitHub Issues
- Submit feature requests
- Join our community discussions
