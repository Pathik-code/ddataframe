"""PyPackage Creation - A sample Python package to get the Data of structure."""

__version__ = "0.1.0"
